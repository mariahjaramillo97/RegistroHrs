# demo-crud-spring-boot
CRUD con Spring Boot utilizando Thymeleaf y Bootstrap

<br>
<b>Vídeo CRUD patron MVC:</b><br>
<b>https://youtu.be/ba8arWqyTAw</b><br>


<b>Vídeo CRUD API Rest:</b><br>
<b>https://youtu.be/xNZEgVJ_4Q0</b><br>

<br>
<b><a href="https://goo.gl/v2Oej4" target="_blank">#VamosPorLos10k</a><b>
<br>
Facebook : https://goo.gl/xhoMZM<br>
Twitter: https://goo.gl/YhHtCL<br>
Instagram: https://bit.ly/2CzrSVP<br>
