package com.example.democrudhrs.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.democrudhrs.model.Registrohrs;
import com.example.democrudhrs.service.api.RegistrohrsServiceAPI;


@Controller
public class RegistrohrsController {
	
	@Autowired
	private RegistrohrsServiceAPI registrohrsServiceAPI;
	
	@RequestMapping("/")
	public String index(Model model) {
		model.addAttribute("list", registrohrsServiceAPI.getAll());
		return "index";
	}
	
	
	@GetMapping("/save/{id}")
	public String showSave(@PathVariable("id") Long id , Model model) {
		if(id != null && id != 0) {
			model.addAttribute("registrohrs", registrohrsServiceAPI.get(id));
		}else {
			model.addAttribute("registrohrs", new Registrohrs());
		}
		return "save";
	}
	
	@PostMapping("/save")
	public String save(Registrohrs registrohrs, Model model) {
		registrohrsServiceAPI.save(registrohrs);
		return "redirect:/";
	}
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable Long id, Model model) {
		registrohrsServiceAPI.delete(id);
		
		return "redirect:/";
	}
	
	
	@GetMapping("/listarhrs/{id}")
	public String showHrs(@PathVariable("id") Long id , Model model) {
		
			model.addAttribute("registrohrs", registrohrsServiceAPI.get(id));
		
		return "listarhrs";
	}
	



}
