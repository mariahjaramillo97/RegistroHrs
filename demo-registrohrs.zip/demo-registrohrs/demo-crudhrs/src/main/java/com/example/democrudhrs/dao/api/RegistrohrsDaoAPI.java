package com.example.democrudhrs.dao.api;

import org.springframework.data.repository.CrudRepository;

import com.example.democrudhrs.model.Registrohrs;

public interface RegistrohrsDaoAPI extends CrudRepository<Registrohrs, Long> {


}
