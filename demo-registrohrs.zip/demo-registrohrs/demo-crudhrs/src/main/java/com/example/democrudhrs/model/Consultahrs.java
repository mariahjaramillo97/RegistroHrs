package com.example.democrudhrs.model;


public class Consultahrs {

	private String horasnormales;

	private String horasnocturnas;

	private String horasdomicales;
	
	private String horasnormalesextra;
	
	private String horasnocturnasextra;
	
	private String horasdomicalesextra;


	public String getHorasnormales() {
		return horasnormales;
	}

	public void setHorasnormales(String horasnormales) {
		this.horasnormales = horasnormales;
	}

	public String getHorasnocturnas() {
		return horasnocturnas;
	}

	public void setHorasnocturnas(String horasnocturnas) {
		this.horasnocturnas = horasnocturnas;
	}

	public String getHorasdomicales() {
		return horasdomicales;
	}

	public void setHorasdomicales(String horasdomicales) {
		this.horasdomicales = horasdomicales;
	}

	public String getHorasnormalesextra() {
		return horasnormalesextra;
	}

	public void setHorasnormalesextra(String horasnormalesextra) {
		this.horasnormalesextra = horasnormalesextra;
	}

	public String getHorasnocturnasextra() {
		return horasnocturnasextra;
	}

	public void setHorasnocturnasextra(String horasnocturnasextra) {
		this.horasnocturnasextra = horasnocturnasextra;
	}

	public String getHorasdomicalesextra() {
		return horasdomicalesextra;
	}

	public void setHorasdomicalesextra(String horasdomicalesextra) {
		this.horasdomicalesextra = horasdomicalesextra;
	}
	
	
	public Consultahrs() 
	{
		
		
	}
	

	public Consultahrs(String horasnormales, String horasnocturnas, String horasdomicales, String horasnormalesextra,
			String horasnocturnasextra, String horasdomicalesextra) {
		super();
		this.horasnormales = horasnormales;
		this.horasnocturnas = horasnocturnas;
		this.horasdomicales = horasdomicales;
		this.horasnormalesextra = horasnormalesextra;
		this.horasnocturnasextra = horasnocturnasextra;
		this.horasdomicalesextra = horasdomicalesextra;
	}
	
	
	
}
