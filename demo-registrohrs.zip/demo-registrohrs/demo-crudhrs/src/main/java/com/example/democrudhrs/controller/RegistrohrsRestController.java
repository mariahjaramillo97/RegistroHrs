package com.example.democrudhrs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.democrudhrs.model.Registrohrs;
import com.example.democrudhrs.service.api.RegistrohrsServiceAPI;

@RestController
@RequestMapping(value = "/api/v1/")
@CrossOrigin("*")
public class RegistrohrsRestController {

	@Autowired
	private RegistrohrsServiceAPI registrohrsServiceAPI;

	@GetMapping(value = "/all")
	public List<Registrohrs> getAll() {
		return registrohrsServiceAPI.getAll();
	}
	
	@GetMapping(value = "/find/{id}")
	public Registrohrs find(@PathVariable Long id) {
		return registrohrsServiceAPI.get(id);
	}

	@PostMapping(value = "/save")
	public ResponseEntity<Registrohrs> save(@RequestBody Registrohrs registrohrs) {
		Registrohrs obj = registrohrsServiceAPI.save(registrohrs);
		return new ResponseEntity<Registrohrs>(obj, HttpStatus.OK);
	}

	@GetMapping(value = "/delete/{id}")
	public ResponseEntity<Registrohrs> delete(@PathVariable Long id) {
		Registrohrs registrohrs = registrohrsServiceAPI.get(id);
		if (registrohrs != null) {
			registrohrsServiceAPI.delete(id);
		}else {
			return new ResponseEntity<Registrohrs>(HttpStatus.NO_CONTENT);
		}
		
		return new ResponseEntity<Registrohrs>(registrohrs, HttpStatus.OK);
	}

}
