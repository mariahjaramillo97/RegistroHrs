package com.example.democrudhrs.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.example.democrudhrs.commons.GenericServiceImpl;
import com.example.democrudhrs.dao.api.RegistrohrsDaoAPI;
import com.example.democrudhrs.model.Registrohrs;
import com.example.democrudhrs.service.api.RegistrohrsServiceAPI;

@Service
public class RegistrohrsServiceImpl extends GenericServiceImpl<Registrohrs, Long> implements RegistrohrsServiceAPI {

	@Autowired
	private RegistrohrsDaoAPI registrohrsDaoAPI;
	
	@Override
	public CrudRepository<Registrohrs, Long> getDao() {
		return registrohrsDaoAPI;
	}


	
	

}
