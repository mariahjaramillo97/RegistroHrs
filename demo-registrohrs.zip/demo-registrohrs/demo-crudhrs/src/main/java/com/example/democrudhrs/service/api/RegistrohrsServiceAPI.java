package com.example.democrudhrs.service.api;

import com.example.democrudhrs.commons.GenericServiceAPI;
import com.example.democrudhrs.model.Registrohrs;

public interface RegistrohrsServiceAPI extends GenericServiceAPI<Registrohrs, Long>  {
	
	
}
